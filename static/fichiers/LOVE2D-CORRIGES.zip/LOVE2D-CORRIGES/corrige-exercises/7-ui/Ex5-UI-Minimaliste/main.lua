local time = 0
local score = 0

function love.update(dt)
    time = time + dt
    score = score + 2 * dt
end

function love.draw()
    love.graphics.clear(0,0,0)
    love.graphics.setColor(1,1,1)
    love.graphics.print("TIME " .. string.format("%02d", math.floor(time)), 10, 10)
    love.graphics.print("SCORE " .. string.format("%04d", math.floor(score)), 10, 30)
end
