local maxHP = 100
local hp = maxHP

function love.keypressed(key)
    if key == "space" then
        hp = hp - 10
        if hp < 0 then hp = 0 end
    elseif key == "r" then
        hp = maxHP
    end
end

function love.draw()
    love.graphics.print("HP", 10, 10)
    local barWidth = 200
    local ratio = hp / maxHP

    love.graphics.setColor(0.5,0,0)
    love.graphics.rectangle("fill", 40, 10, barWidth, 20)
    love.graphics.setColor(0,1,0)
    love.graphics.rectangle("fill", 40, 10, barWidth * ratio, 20)
    love.graphics.setColor(1,1,1)
    love.graphics.print(hp .. "/" .. maxHP, 250, 10)
end
