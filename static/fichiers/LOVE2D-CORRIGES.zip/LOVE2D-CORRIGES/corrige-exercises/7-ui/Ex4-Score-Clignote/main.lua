local score = 0
local flashTimer = 0

function love.keypressed(key)
    if key == "space" then
        score = score + 10
        flashTimer = 0.3
    end
end

function love.update(dt)
    if flashTimer > 0 then
        flashTimer = flashTimer - dt
    end
end

function love.draw()
    if flashTimer > 0 then
        love.graphics.setColor(1,1,0)
    else
        love.graphics.setColor(1,1,1)
    end
    love.graphics.print("Score : " .. score, 10, 10)
    love.graphics.setColor(1,1,1)
    love.graphics.print("Space = +10", 10, 30)
end
