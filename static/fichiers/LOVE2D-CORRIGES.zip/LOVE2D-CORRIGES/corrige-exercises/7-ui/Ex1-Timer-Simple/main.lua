local time = 0
local running = true

function love.keypressed(key)
    if key == "space" then
        running = not running
    end
end

function love.update(dt)
    if running then
        time = time + dt
    end
end

function love.draw()
    love.graphics.print("Temps : " .. math.floor(time), 10, 10)
    love.graphics.print("Space = start/stop", 10, 30)
end
