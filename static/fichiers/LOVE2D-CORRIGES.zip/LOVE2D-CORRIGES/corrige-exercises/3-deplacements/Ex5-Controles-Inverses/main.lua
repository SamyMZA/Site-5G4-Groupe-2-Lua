local player = { x = 200, y = 200, speed = 200, r = 20 }
local inverted = false
local timer = 0

function love.keypressed(key)
    if key == "e" and not inverted then
        inverted = true
        timer = 3
    end
end

function love.update(dt)
    if inverted then
        timer = timer - dt
        if timer <= 0 then
            inverted = false
        end
    end

    local dir = inverted and -1 or 1

    if love.keyboard.isDown("w") then player.y = player.y - dir * player.speed * dt end
    if love.keyboard.isDown("s") then player.y = player.y + dir * player.speed * dt end
    if love.keyboard.isDown("a") then player.x = player.x - dir * player.speed * dt end
    if love.keyboard.isDown("d") then player.x = player.x + dir * player.speed * dt end
end

function love.draw()
    love.graphics.print("Ex 3.5 - E inverse controles", 10, 10)
    if inverted then
        love.graphics.print("CONTROLES INVERSES !", 10, 30)
    end
    love.graphics.circle("fill", player.x, player.y, player.r)
end
