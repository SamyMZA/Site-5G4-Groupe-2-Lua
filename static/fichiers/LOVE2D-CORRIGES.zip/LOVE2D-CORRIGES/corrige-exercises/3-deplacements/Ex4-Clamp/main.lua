local player = { x = 200, y = 200, speed = 200, r = 20 }

local function clampPlayer()
    local w, h = love.graphics.getWidth(), love.graphics.getHeight()
    if player.x < player.r then player.x = player.r end
    if player.x > w - player.r then player.x = w - player.r end
    if player.y < player.r then player.y = player.r end
    if player.y > h - player.r then player.y = h - player.r end
end

function love.update(dt)
    if love.keyboard.isDown("w") then player.y = player.y - player.speed * dt end
    if love.keyboard.isDown("s") then player.y = player.y + player.speed * dt end
    if love.keyboard.isDown("a") then player.x = player.x - player.speed * dt end
    if love.keyboard.isDown("d") then player.x = player.x + player.speed * dt end
    clampPlayer()
end

function love.draw()
    love.graphics.print("Ex 3.4 - Clamp écran", 10, 10)
    love.graphics.circle("fill", player.x, player.y, player.r)
end
