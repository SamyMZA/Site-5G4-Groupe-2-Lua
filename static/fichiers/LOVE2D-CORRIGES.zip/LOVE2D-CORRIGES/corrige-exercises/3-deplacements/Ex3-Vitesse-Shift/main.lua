local player = { x = 200, y = 200, speed = 160, r = 20 }

function love.update(dt)
    local currentSpeed = player.speed
    if love.keyboard.isDown("lshift") or love.keyboard.isDown("rshift") then
        currentSpeed = currentSpeed * 2
    end

    if love.keyboard.isDown("w") then player.y = player.y - currentSpeed * dt end
    if love.keyboard.isDown("s") then player.y = player.y + currentSpeed * dt end
    if love.keyboard.isDown("a") then player.x = player.x - currentSpeed * dt end
    if love.keyboard.isDown("d") then player.x = player.x + currentSpeed * dt end
end

function love.draw()
    love.graphics.print("Ex 3.3 - Shift = sprint", 10, 10)
    love.graphics.circle("fill", player.x, player.y, player.r)
end
