local player = { x = 200, y = 200, speed = 200, size = 40 }

function love.update(dt)
    if love.keyboard.isDown("w") then player.y = player.y - player.speed * dt end
    if love.keyboard.isDown("s") then player.y = player.y + player.speed * dt end
    if love.keyboard.isDown("a") then player.x = player.x - player.speed * dt end
    if love.keyboard.isDown("d") then player.x = player.x + player.speed * dt end
end

function love.draw()
    love.graphics.setColor(1,1,1)
    love.graphics.print("Ex 3.1 - WASD", 10, 10)
    love.graphics.rectangle("fill", player.x, player.y, player.size, player.size)
end
