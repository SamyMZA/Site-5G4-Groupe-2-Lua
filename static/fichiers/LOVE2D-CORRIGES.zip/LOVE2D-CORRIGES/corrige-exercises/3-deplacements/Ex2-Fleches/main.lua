local player = { x = 200, y = 200, speed = 200, r = 20 }

function love.update(dt)
    if love.keyboard.isDown("up") then player.y = player.y - player.speed * dt end
    if love.keyboard.isDown("down") then player.y = player.y + player.speed * dt end
    if love.keyboard.isDown("left") then player.x = player.x - player.speed * dt end
    if love.keyboard.isDown("right") then player.x = player.x + player.speed * dt end
end

function love.draw()
    love.graphics.setColor(1,1,1)
    love.graphics.print("Ex 3.2 - Flèches", 10, 10)
    love.graphics.circle("fill", player.x, player.y, player.r)
end
