local box = { x = 100, y = 100, w = 40, h = 40, speedX = 80, speedY = 60 }

function love.update(dt)
    box.speedX = box.speedX + 10 * dt
    box.speedY = box.speedY + 10 * dt

    box.x = box.x + box.speedX * dt
    box.y = box.y + box.speedY * dt

    local sw, sh = love.graphics.getWidth(), love.graphics.getHeight()

    if box.x < 0 then box.x = 0; box.speedX = -box.speedX end
    if box.x + box.w > sw then box.x = sw - box.w; box.speedX = -box.speedX end
    if box.y < 0 then box.y = 0; box.speedY = -box.speedY end
    if box.y + box.h > sh then box.y = sh - box.h; box.speedY = -box.speedY end
end

function love.draw()
    love.graphics.rectangle("fill", box.x, box.y, box.w, box.h)
end
