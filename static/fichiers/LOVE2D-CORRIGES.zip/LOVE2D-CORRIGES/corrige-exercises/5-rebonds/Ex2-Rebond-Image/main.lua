local img
local x, y = 200, 120
local speedX, speedY = 150, 190
local w, h

function love.load()
    img = love.graphics.newImage("assets/images/player.png")
    w, h = img:getWidth(), img:getHeight()
end

function love.update(dt)
    x = x + speedX * dt
    y = y + speedY * dt

    local sw, sh = love.graphics.getWidth(), love.graphics.getHeight()

    if x < 0 then x = 0; speedX = -speedX end
    if x + w > sw then x = sw - w; speedX = -speedX end
    if y < 0 then y = 0; speedY = -speedY end
    if y + h > sh then y = sh - h; speedY = -speedY end
end

function love.draw()
    love.graphics.setColor(1,1,1)
    love.graphics.draw(img, x, y)
end
