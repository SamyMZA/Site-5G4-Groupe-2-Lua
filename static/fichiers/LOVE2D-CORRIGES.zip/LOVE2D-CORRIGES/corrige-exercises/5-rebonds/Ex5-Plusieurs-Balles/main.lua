local balls = {}

local function spawnBall()
    local b = {
        x = math.random(50, 750),
        y = math.random(50, 550),
        r = 15,
        speedX = math.random(-150,150),
        speedY = math.random(-150,150)
    }
    table.insert(balls, b)
end

function love.load()
    math.randomseed(os.time())
    for i=1,5 do spawnBall() end
end

function love.update(dt)
    local sw, sh = love.graphics.getWidth(), love.graphics.getHeight()

    for _, b in ipairs(balls) do
        b.x = b.x + b.speedX * dt
        b.y = b.y + b.speedY * dt

        if b.x - b.r < 0 then b.x = b.r; b.speedX = -b.speedX end
        if b.x + b.r > sw then b.x = sw - b.r; b.speedX = -b.speedX end
        if b.y - b.r < 0 then b.y = b.r; b.speedY = -b.speedY end
        if b.y + b.r > sh then b.y = sh - b.r; b.speedY = -b.speedY end
    end
end

function love.draw()
    for _, b in ipairs(balls) do
        love.graphics.circle("fill", b.x, b.y, b.r)
    end
end
