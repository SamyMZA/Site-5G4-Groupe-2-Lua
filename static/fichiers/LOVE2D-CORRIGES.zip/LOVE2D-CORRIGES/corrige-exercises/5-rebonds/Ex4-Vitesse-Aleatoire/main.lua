local box = { x = 150, y = 120, w = 40, h = 40, speedX = 120, speedY = 160 }

local function randomizeSpeed(axisSpeed)
    local sign = axisSpeed < 0 and -1 or 1
    return sign * (80 + math.random(0,120))
end

function love.update(dt)
    box.x = box.x + box.speedX * dt
    box.y = box.y + box.speedY * dt

    local sw, sh = love.graphics.getWidth(), love.graphics.getHeight()

    if box.x < 0 then
        box.x = 0
        box.speedX = randomizeSpeed(-box.speedX)
    elseif box.x + box.w > sw then
        box.x = sw - box.w
        box.speedX = randomizeSpeed(-box.speedX)
    end

    if box.y < 0 then
        box.y = 0
        box.speedY = randomizeSpeed(-box.speedY)
    elseif box.y + box.h > sh then
        box.y = sh - box.h
        box.speedY = randomizeSpeed(-box.speedY)
    end
end

function love.draw()
    love.graphics.rectangle("fill", box.x, box.y, box.w, box.h)
end
