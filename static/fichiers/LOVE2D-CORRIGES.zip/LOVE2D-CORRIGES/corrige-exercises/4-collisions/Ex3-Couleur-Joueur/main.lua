local player = { x = 50, y = 50, w = 40, h = 40, speed = 200 }
local box = { x = 250, y = 120, w = 80, h = 80 }
local colliding = false

local function checkCollision(a,b)
    return a.x < b.x + b.w and b.x < a.x + a.w and a.y < b.y + b.h and b.y < a.y + a.h
end

function love.update(dt)
    if love.keyboard.isDown("w") then player.y = player.y - player.speed * dt end
    if love.keyboard.isDown("s") then player.y = player.y + player.speed * dt end
    if love.keyboard.isDown("a") then player.x = player.x - player.speed * dt end
    if love.keyboard.isDown("d") then player.x = player.x + player.speed * dt end

    colliding = checkCollision(player, box)
end

function love.draw()
    if colliding then love.graphics.setColor(1,1,0) else love.graphics.setColor(0,0.4,1) end
    love.graphics.rectangle("fill", player.x, player.y, player.w, player.h)

    love.graphics.setColor(1,0,0)
    love.graphics.rectangle("fill", box.x, box.y, box.w, box.h)
end
