local player = { x = 60, y = 60, w = 30, h = 30, speed = 200 }
local obstacles = {
    { x = 200, y = 80, w = 80, h = 40 },
    { x = 320, y = 200, w = 50, h = 90 },
    { x = 120, y = 260, w = 120, h = 30 }
}
local hitIndex = nil

local function checkCollision(a,b)
    return a.x < b.x + b.w and b.x < a.x + a.w and a.y < b.y + b.h and b.y < a.y + a.h
end

function love.update(dt)
    if love.keyboard.isDown("w") then player.y = player.y - player.speed * dt end
    if love.keyboard.isDown("s") then player.y = player.y + player.speed * dt end
    if love.keyboard.isDown("a") then player.x = player.x - player.speed * dt end
    if love.keyboard.isDown("d") then player.x = player.x + player.speed * dt end

    hitIndex = nil
    for i, box in ipairs(obstacles) do
        if checkCollision(player, box) then
            hitIndex = i
            break
        end
    end
end

function love.draw()
    love.graphics.setColor(0,0.4,1)
    love.graphics.rectangle("fill", player.x, player.y, player.w, player.h)

    for i, box in ipairs(obstacles) do
        if i == hitIndex then
            love.graphics.setColor(1,0,0)
        else
            love.graphics.setColor(1,1,1)
        end
        love.graphics.rectangle("line", box.x, box.y, box.w, box.h)
    end
end
