local px, py, pr = 120, 200, 20
local ex, ey, er = 300, 200, 30
local hit = false

local function circleCollision(x1,y1,r1,x2,y2,r2)
    local dx = x2 - x1
    local dy = y2 - y1
    local dist2 = dx*dx + dy*dy
    local r = r1 + r2
    return dist2 < r*r
end

function love.update(dt)
    if love.keyboard.isDown("right") then px = px + 200 * dt end
    if love.keyboard.isDown("left") then px = px - 200 * dt end
    hit = circleCollision(px,py,pr,ex,ey,er)
end

function love.draw()
    if hit then love.graphics.setColor(1,0,0) else love.graphics.setColor(0,1,0) end
    love.graphics.circle("fill", px, py, pr)
    love.graphics.setColor(1,1,1)
    love.graphics.circle("line", ex, ey, er)
end
