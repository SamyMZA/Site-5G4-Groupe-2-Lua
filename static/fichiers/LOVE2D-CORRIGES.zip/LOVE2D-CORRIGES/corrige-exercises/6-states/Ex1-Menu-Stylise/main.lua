local gameState = "menu"

function love.keypressed(key)
    if key == "return" then 
        gameState = "game" 
    end
end

function love.draw()
    if gameState == "menu" then
        love.graphics.clear(0.1,0.1,0.15)
        love.graphics.setColor(1,1,1)

        love.graphics.printf("Mon Jeu", 0, 180, love.graphics.getWidth(), "center")
        love.graphics.printf("Appuyez sur ENTREE", 0, 240, love.graphics.getWidth(), "center")
    else
        love.graphics.print("Jeu en cours (demo)", 10, 10)
    end
end
