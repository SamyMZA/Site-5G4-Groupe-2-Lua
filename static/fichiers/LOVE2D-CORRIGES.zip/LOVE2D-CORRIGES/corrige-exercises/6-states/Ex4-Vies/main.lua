local lives = 3
local gameState = "game"

function love.keypressed(key)
    if key == "space" and gameState == "game" then
        lives = lives - 1
        if lives <= 0 then
            gameState = "gameover"
        end

    elseif key == "r" and gameState == "gameover" then
        lives = 3
        gameState = "game"
    end
end

function love.draw()
    love.graphics.print("Vies : " .. lives, 10, 10)

    if gameState == "gameover" then
        love.graphics.printf("GAME OVER\nAppuyez sur R", 
            0, 200, love.graphics.getWidth(), "center")
    end
end
