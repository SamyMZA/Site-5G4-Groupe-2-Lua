local gameState = "game"
local player = { x = 200, y = 200, speed = 200, r = 20 }

function love.keypressed(key)
    if key == "p" then
        if gameState == "game" then
            gameState = "pause"
        elseif gameState == "pause" then
            gameState = "game"
        end
    end
end

function love.update(dt)
    if gameState ~= "game" then return end
    if love.keyboard.isDown("w") then player.y = player.y - player.speed * dt end
    if love.keyboard.isDown("s") then player.y = player.y + player.speed * dt end
    if love.keyboard.isDown("a") then player.x = player.x - player.speed * dt end
    if love.keyboard.isDown("d") then player.x = player.x + player.speed * dt end
end

function love.draw()
    love.graphics.circle("fill", player.x, player.y, player.r)
    if gameState == "pause" then
        love.graphics.setColor(0,0,0,0.5)
        love.graphics.rectangle("fill", 0,0,love.graphics.getWidth(), love.graphics.getHeight())
        love.graphics.setColor(1,1,1)
        love.graphics.printf("PAUSE (P pour reprendre)", 0, 200, love.graphics.getWidth(), "center")
    end
end
