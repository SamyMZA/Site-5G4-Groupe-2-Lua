local gameState = "menu"
local box = { x = 50, y = 200, w = 80, h = 40, speedX = 120 }

function love.keypressed(key)
    if key == "return" then gameState = "game" end
end

function love.update(dt)
    if gameState == "menu" then
        box.x = box.x + box.speedX * dt
        local w = love.graphics.getWidth()
        if box.x < 0 or box.x + box.w > w then
            box.speedX = -box.speedX
        end
    end
end

function love.draw()
    local w = love.graphics.getWidth()
    if gameState == "menu" then
        love.graphics.clear(0.08,0.08,0.12)

        love.graphics.setColor(0.2,0.6,1)
        love.graphics.rectangle("fill", box.x, box.y, box.w, box.h)

        love.graphics.setColor(1,1,1)
        love.graphics.printf("MENU\nAppuyez sur ENTREE", 0, 100, w, "center")
    else
        love.graphics.print("Jeu en cours...", 10, 10)
    end
end
