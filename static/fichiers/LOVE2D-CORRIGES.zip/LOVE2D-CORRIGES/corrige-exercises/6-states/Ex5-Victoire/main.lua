local gameState = "game"
local time = 0
local targetTime = 10

function love.update(dt)
    if gameState == "game" then
        time = time + dt
        if time >= targetTime then
            gameState = "win"
        end
    end
end

function love.keypressed(key)
    if gameState == "win" and key == "r" then
        time = 0
        gameState = "game"
    end
end

function love.draw()
    if gameState == "game" then
        love.graphics.print("Survis jusqu'à " .. targetTime .. "s", 10, 10)
        love.graphics.print("Temps : " .. math.floor(time), 10, 30)
    else
        love.graphics.printf("VICTOIRE !\nAppuyez sur R pour rejouer",
            0, 200, love.graphics.getWidth(), "center")
    end
end
