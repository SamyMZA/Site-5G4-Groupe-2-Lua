function love.load()
end

function love.update(dt)
end

function love.draw()
    love.graphics.setColor(1, 0, 0, 1)
    love.graphics.rectangle("fill", 100, 80, 200, 120)
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print("Exercice 1 - Rectangle rouge", 10, 10)
end
