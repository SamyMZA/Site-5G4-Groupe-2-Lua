local playerImg

function love.load()
    playerImg = love.graphics.newImage("assets/images/player.png")
end

function love.draw()
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print("Exercice 3 - Image player.png", 10, 10)
    love.graphics.draw(playerImg, 200, 150)
end
