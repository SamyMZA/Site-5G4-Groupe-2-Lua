function love.draw()
    love.graphics.setColor(0, 0, 1, 1)
    love.graphics.circle("fill", 200, 150, 60)
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print("Exercice 2 - Cercle bleu", 10, 10)
end
