local playerImg
local x, y = 100, 150
local speed = 120

function love.load()
    playerImg = love.graphics.newImage("assets/images/player.png")
end

function love.update(dt)
    x = x + speed * dt
    if x > love.graphics.getWidth() then
        x = -playerImg:getWidth()
    end
end

function love.draw()
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print("Exercice 4 - Image qui se déplace", 10, 10)
    love.graphics.draw(playerImg, x, y)
end
