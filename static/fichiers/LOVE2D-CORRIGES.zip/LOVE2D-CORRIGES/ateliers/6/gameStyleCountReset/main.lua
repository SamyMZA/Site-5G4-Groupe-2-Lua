local gameState = "menu"
local player = {x = 400, y = 300, speed = 200}
local enemy = {x = 100, y = 100, speed = 100}
local survivalTime = 0

function love.keypressed(key)
    if gameState == "menu" and key == "return" then
        gameState = "game"
        survivalTime = 0

    end

    if gameState == "gameover" and key == "r" then
        restartGame()
    end
end

function restartGame()
    player.x, player.y = 400, 300
    enemy.x, enemy.y = 100, 100
    gameState = "game"
end

function checkCollision()
    local dx = player.x - enemy.x
    local dy = player.y - enemy.y
    return dx*dx + dy*dy < 40*40
end

function love.update(dt)
     if gameState == "game" then
        survivalTime = survivalTime + dt
    end

    if gameState == "game" then
        if love.keyboard.isDown("w") then player.y = player.y - player.speed * dt end
        if love.keyboard.isDown("s") then player.y = player.y + player.speed * dt end
        if love.keyboard.isDown("a") then player.x = player.x - player.speed * dt end
        if love.keyboard.isDown("d") then player.x = player.x + player.speed * dt end

        local dx = player.x - enemy.x
        local dy = player.y - enemy.y
        local dist = math.sqrt(dx*dx + dy*dy)

        enemy.x = enemy.x + (dx/dist) * enemy.speed * dt
        enemy.y = enemy.y + (dy/dist) * enemy.speed * dt

        if checkCollision() then
            gameState = "gameover"
        end

        if survivalTime == 5 then
            gameState = "win"
        end           

    end
end

function love.draw()
    if gameState == "menu" then
        love.graphics.printf("MENU\nAppuyez sur ENTREE pour commencer", 0, 220, 800, "center")
    end

    if gameState == "game" then
        love.graphics.setColor(0, 1, 0)
        love.graphics.circle("fill", player.x, player.y, 20)

        love.graphics.setColor(1, 0, 0)
        love.graphics.circle("fill", enemy.x, enemy.y, 20)

         love.graphics.print("Temps : " .. math.floor(survivalTime), 10, 10)
    end

    if gameState == "gameover" then
        love.graphics.printf("GAME OVER\nAppuyez sur R pour recommencer", 0, 220, 800, "center")
    end

    if gameState == "win" then
        love.graphics.printf("YOU WIN!\nAppuyez sur R pour recommencer", 0, 220, 800, "center")
    end
end