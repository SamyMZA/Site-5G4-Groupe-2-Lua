local time = 0
local score = 0

function love.update(dt)
    time = time + dt
    score = score + 5 * dt -- score augmente lentement
end

function love.draw()
    -- texte blanc
    love.graphics.setColor(1, 1, 1)

    -- timer
    love.graphics.print("Temps : " .. math.floor(time), 10, 10)

    -- score
    love.graphics.print("Score : " .. math.floor(score), 10, 30)

    -- rappel controls (optionnel)
    love.graphics.setColor(1, 1, 0)
    love.graphics.print("WASD pour se déplacer", 10, love.graphics.getHeight() - 30)
    
end