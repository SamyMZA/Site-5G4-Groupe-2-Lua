local gameState = "menu"
local score = 0
local time = 0
local highScore = 0

function love.update(dt)
    if gameState == "game" then
        time = time + dt
        score = score + 5 * dt
    end
end

function love.keypressed(key)
    if gameState == "menu" and key == "return" then
        time = 0
        score = 0
        gameState = "game"
    end

    if gameState == "gameover" and key == "r" then
        time = 0
        score = 0
        gameState = "game"
    end
end

function love.draw()
    if gameState == "menu" then
        love.graphics.printf("MENU\nAppuyez sur ENTREE", 0, 200, 800, "center")
        return
    end

    if gameState == "game" then
        -- UI
        love.graphics.setColor(0, 0, 0, 0.4)
        love.graphics.rectangle("fill", 0, 0, 180, 60)

        love.graphics.setColor(1, 1, 1)
        love.graphics.print("Temps : " .. math.floor(time), 10, 10)
        love.graphics.print("Score : " .. math.floor(score), 10, 30)
    end

    if gameState == "gameover" then
        love.graphics.printf("GAME OVER\nAppuyez sur R", 0, 200, 800, "center")

        love.graphics.print("Score final : " .. math.floor(score), 10, 10)
        love.graphics.print("Record : " .. math.floor(highScore), 10, 30)
    end
end