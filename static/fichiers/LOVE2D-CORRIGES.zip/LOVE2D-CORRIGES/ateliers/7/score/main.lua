local score = 0

function love.update(dt)
    score = score + 1 * dt
end

function love.draw()
    love.graphics.print("Score : " .. math.floor(score), 10, 30)
end