local time = 0

function love.update(dt)
    time = time + dt
end

function love.draw()
    love.graphics.print("Temps : " .. math.floor(time), 10, 10)
end