local score = 0
local highScore = 0

function love.update(dt)
    score = score + dt
end

function love.keypressed(key)
    if key == "space" then
        if score > highScore then
            highScore = score
        end
        score = 0
    end
end

function love.draw()
    love.graphics.print("Score : " .. math.floor(score), 10, 10)
    love.graphics.print("Record : " .. math.floor(highScore), 10, 30)
end