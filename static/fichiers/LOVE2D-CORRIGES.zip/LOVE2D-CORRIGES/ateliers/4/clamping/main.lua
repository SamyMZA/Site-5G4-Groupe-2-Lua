local player = {
    x = 200,
    y = 200,
    speed = 220,
    radius = 20
}

local function clampPlayer()
    local w = love.graphics.getWidth()
    local h = love.graphics.getHeight()

    if player.x < player.radius then player.x = player.radius end
    if player.x > w - player.radius then player.x = w - player.radius end

    if player.y < player.radius then player.y = player.radius end
    if player.y > h - player.radius then player.y = h - player.radius end
end

function love.update(dt)
    if love.keyboard.isDown("w") then
        player.y = player.y - player.speed * dt
    end
    if love.keyboard.isDown("s") then
        player.y = player.y + player.speed * dt
    end
    if love.keyboard.isDown("a") then
        player.x = player.x - player.speed * dt
    end
    if love.keyboard.isDown("d") then
        player.x = player.x + player.speed * dt
    end

    clampPlayer()
end

function love.draw()
    love.graphics.setColor(1, 1, 1)
    love.graphics.circle("fill", player.x, player.y, player.radius)
end