function love.load()
    -- rien à charger ici
end

function love.update(dt)
    -- logique du jeu (vide pour ce chapitre)
end

function love.draw()
    

    -- cercle bleu
    love.graphics.setColor(0, 0, 1, 1)
    love.graphics.circle("fill", 300, 150, 40)

   
end