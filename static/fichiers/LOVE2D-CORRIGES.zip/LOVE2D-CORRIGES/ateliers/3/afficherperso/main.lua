local playerImg
local playerX = 200
local playerY = 200

function love.load()
    playerImg = love.graphics.newImage("assets/images/player.png")
end

function love.update(dt)
    -- rien pour l'instant
end

function love.draw()
    love.graphics.setColor(1, 1, 1, 1) -- reset couleur
    love.graphics.draw(playerImg, playerX, playerY)
end
