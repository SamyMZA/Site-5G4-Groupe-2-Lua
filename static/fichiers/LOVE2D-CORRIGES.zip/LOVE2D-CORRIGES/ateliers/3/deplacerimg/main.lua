local img
local x = 100
local y = 100
local speed = 200 -- pixels/sec

function love.load()
    img = love.graphics.newImage("assets/images/player.png")
end

function love.update(dt)
    x = x + speed * dt      -- mouvement automatique horizontal
end

function love.draw()
    love.graphics.draw(img, x, y)
end
