local box = {
    x = 100,
    y = 100,
    w = 50,
    h = 50,
    speedX = 180,
    speedY = 140
}

function love.update(dt)
    box.x = box.x + box.speedX * dt
    box.y = box.y + box.speedY * dt

    local screenW = love.graphics.getWidth()
    local screenH = love.graphics.getHeight()

    if box.x < 0 then
        box.x = 0
        box.speedX = -box.speedX
    end

    if box.x + box.w > screenW then
        box.x = screenW - box.w
        box.speedX = -box.speedX
    end

    if box.y < 0 then
        box.y = 0
        box.speedY = -box.speedY
    end

    if box.y + box.h > screenH then
        box.y = screenH - box.h
        box.speedY = -box.speedY
    end
end

function love.draw()
    love.graphics.setColor(1, 0.2, 0.2)
    love.graphics.rectangle("fill", box.x, box.y, box.w, box.h)
end