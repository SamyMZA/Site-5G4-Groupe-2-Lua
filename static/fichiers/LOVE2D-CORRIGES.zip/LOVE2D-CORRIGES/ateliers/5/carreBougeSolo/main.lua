local box = {
    x = 100,
    y = 100,
    w = 50,
    h = 50,
    speedX = 180,
    speedY = 140
}

function love.update(dt)
    box.x = box.x + box.speedX * dt
    box.y = box.y + box.speedY * dt
end

function love.draw()
    love.graphics.setColor(1, 0, 0)
    love.graphics.rectangle("fill", box.x, box.y, box.w, box.h)
end