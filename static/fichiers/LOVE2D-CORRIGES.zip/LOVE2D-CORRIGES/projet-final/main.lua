local SCALE = 0.12
local fade = 1
local fadeSpeed = 1.2
local hitboxShrink = 0.7   

local gameState = "menu"

local player = {
    x = 400,
    y = 300,
    speed = 200,
    w = 40,
    h = 40,
    img = nil
}

local enemies = {}
local enemySpeed = 150
local enemyImg = nil

local score = 0
local timeAlive = 0
local highScore = 0


local function checkCollision(a, b)
    return  a.x < b.x + b.w and
            b.x < a.x + a.w and
            a.y < b.y + b.h and
            b.y < a.y + a.h
end

local function clampPlayer()
    local sw = love.graphics.getWidth()
    local sh = love.graphics.getHeight()

    if player.x < 0 then player.x = 0 end
    if player.y < 0 then player.y = 0 end
    if player.x + player.w > sw then player.x = sw - player.w end
    if player.y + player.h > sh then player.y = sh - player.h end
end

local function spawnEnemy()
    local sw = love.graphics.getWidth()
    local sh = love.graphics.getHeight()

    local ex, ey
    repeat
        ex = math.random(0, sw - 40)
        ey = math.random(0, sh - 40)
    until (ex - player.x)^2 + (ey - player.y)^2 > 250^2 --formule SAFE

    local w = enemyImg:getWidth() * SCALE
    local h = enemyImg:getHeight() * SCALE

    w = w * hitboxShrink
    h = h * hitboxShrink

    table.insert(enemies, {
        x = ex,
        y = ey,
        w = w,
        h = h,
        speedX = (math.random() < 0.5 and -1 or 1) * (enemySpeed + math.random(0, 60)),
        speedY = (math.random() < 0.5 and -1 or 1) * (enemySpeed + math.random(0, 60))
    })
end

local function restartGame()
    player.x = 400
    player.y = 300

    enemies = {}
    for i = 1, 3 do
        spawnEnemy()
    end

    score = 0
    timeAlive = 0
    fade = 1
    gameState = "game"
end


function love.load()
    math.randomseed(os.time())

    player.img = love.graphics.newImage("assets/images/player.png")
    enemyImg = love.graphics.newImage("assets/images/enemy.png")

    player.w = player.img:getWidth() * SCALE * hitboxShrink
    player.h = player.img:getHeight() * SCALE * hitboxShrink

    gameState = "menu"
end


function love.update(dt)
    fade = math.max(0, fade - fadeSpeed * dt)

    if gameState == "menu" then return end
    if gameState == "game" then

        timeAlive = timeAlive + dt
        score = score + 5 * dt

        if love.keyboard.isDown("w") then player.y = player.y - player.speed * dt end
        if love.keyboard.isDown("s") then player.y = player.y + player.speed * dt end
        if love.keyboard.isDown("a") then player.x = player.x - player.speed * dt end
        if love.keyboard.isDown("d") then player.x = player.x + player.speed * dt end

        clampPlayer()

        local sw = love.graphics.getWidth()
        local sh = love.graphics.getHeight()

        for _, e in ipairs(enemies) do
            e.x = e.x + e.speedX * dt
            e.y = e.y + e.speedY * dt

            if e.x < 0 then e.x = 0; e.speedX = -e.speedX end
            if e.x + e.w > sw then e.x = sw - e.w; e.speedX = -e.speedX end

            if e.y < 0 then e.y = 0; e.speedY = -e.speedY end
            if e.y + e.h > sh then e.y = sh - e.h; e.speedY = -e.speedY end

            if checkCollision(player, e) then
                if score > highScore then highScore = score end
                fade = 1
                gameState = "gameover"
            end
        end

        if timeAlive > 8 * (#enemies - 2) then
            spawnEnemy()
        end
    end
end


function love.keypressed(key)
    if gameState == "menu" and key == "return" then
        restartGame()
    end

    if gameState == "gameover" and key == "r" then
        restartGame()
    end
end


function love.draw()
    local w = love.graphics.getWidth()

    love.graphics.clear(0.05, 0.05, 0.07)

    if gameState == "menu" then
        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.printf("SURVIVE!", 0, 180, w, "center")
        love.graphics.printf("Appuyez sur ENTREE", 0, 260, w, "center")
        return
    end

    if gameState == "game" then
        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.print("Temps : " .. math.floor(timeAlive), 10, 10)
        love.graphics.print("Score : " .. math.floor(score), 10, 30)
        love.graphics.print("Record : " .. math.floor(highScore), 10, 50)

        -- dessine joueurs
        love.graphics.draw(player.img, player.x, player.y, 0, SCALE, SCALE)

        -- dessine enemies
        for _, e in ipairs(enemies) do
            love.graphics.draw(enemyImg, e.x, e.y, 0, SCALE, SCALE)
        end
    end

    if gameState == "gameover" then
        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.printf("GAME OVER", 0, 180, w, "center")
        love.graphics.printf("Appuyez sur R pour recommencer", 0, 260, w, "center")
    end

    love.graphics.setColor(0, 0, 0, fade)
    love.graphics.rectangle("fill", 0, 0, w, love.graphics.getHeight())
end
